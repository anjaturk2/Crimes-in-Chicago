library(dplyr)
library(readr)
library(stringr)

crimes<-readRDS(file="./data/Crime.Rds")
crimes <- crimes[,-1]
data2<-crimes

#Selecting Primary Types
vars<-c( "THEFT","MOTOR VEHICLE THEFT","BURGLARY","ROBBERY")
#"ASSAULT","CRIMINAL DAMAGE","KIDNAPPING","ARSON"
#"NON-CRIMINAL","INTIMIDATION","OBSCENITY",
#"PUBLIC INDECENCY","OTHER NARCOTIC VIOLATION","INTERFERENCE WITH PUBLIC OFFICER",
#"STALKING","GAMBLING","LIQUOR LAW VIOLATION","OTHER OFFENSE","NARCOTICS",
#"PUBLIC PEACE VIOLATION","WEAPONS VIOLATION","PROSTITUTION","OFFENSE INVOLVING CHILDREN",
#"CRIM SEXUAL ASSAULT","HOMICIDE","SEX OFFENSE","BATTERY","DECEPTIVE PRACTICE",
#,"CRIMINAL TRESPASS"

crimes<-filter(crimes, Primary.Type %in% vars)

#Merging and selecting Location Description

crimes$Location.Description[crimes$Location.Description=="RESIDENCE-GARAGE"] <- "RESIDENCE"
crimes$Location.Description[crimes$Location.Description=="DRIVEWAY - RESIDENTIAL"] <- "RESIDENCE"
crimes$Location.Description[crimes$Location.Description=="RESIDENTIAL YARD (FRONT/BACK)"] <- "RESIDENCE"
crimes$Location.Description[crimes$Location.Description=="RESIDENCE PORCH/HALLWAY"] <- "RESIDENCE"
crimes$Location.Description[crimes$Location.Description=="APARTMENT"] <- "RESIDENCE"

crimes$Location.Description[crimes$Location.Description=="PARKING LOT/GARAGE(NON.RESID.)"] <- "PARKING LOT"
crimes$Location.Description[crimes$Location.Description=="CHA PARKING LOT/GROUNDS"] <- "PARKING LOT"
crimes$Location.Description[crimes$Location.Description=="AIRPORT PARKING LOT"] <- "PARKING LOT"

crimes$Location.Description[crimes$Location.Description=="SCHOOL, PUBLIC, BUILDING"] <- "SCHOOL/COLLEGE/UNIVERSITY"
crimes$Location.Description[crimes$Location.Description=="SPORTS ARENA/STADIUM"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="COLLEGE/UNIVERSITY GROUNDS"] <- "SCHOOL/COLLEGE/UNIVERSITY"
crimes$Location.Description[crimes$Location.Description=="COLLEGE/UNIVERSITY RESIDENCE HALL"] <- "SCHOOL/COLLEGE/UNIVERSITY"
crimes$Location.Description[crimes$Location.Description=="SCHOOL, PUBLIC, BUILDING"] <- "SCHOOL/COLLEGE/UNIVERSITY"
crimes$Location.Description[crimes$Location.Description=="SCHOOL, PUBLIC, GROUNDS"] <- "SCHOOL/COLLEGE/UNIVERSITY"
crimes$Location.Description[crimes$Location.Description=="FEDERAL BUILDING"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="FIRE STATION"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="MOVIE HOUSE/THEATER"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="CHURCH/SYNAGOGUE/PLACE OF WORSHIP"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="GOVERNMENT BUILDING/PROPERTY"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="LIBRARY"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="HOSPITAL BUILDING/GROUNDS"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="MEDICAL/DENTAL OFFICE"] <- "PUBLIC BUILDING/GROUNDS"

crimes$Location.Description[crimes$Location.Description=="STREET"] <- "STREET/SIDEWALK/PARK"
crimes$Location.Description[crimes$Location.Description=="SIDEWALK"] <- "STREET/SIDEWALK/PARK"
crimes$Location.Description[crimes$Location.Description=="PARK PROPERTY"] <- "STREET/SIDEWALK/PARK"

crimes$Location.Description[crimes$Location.Description=="AIRPORT TRANSPORTATION SYSTEM (ATS)"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="AIRPORT EXTERIOR - SECURE AREA"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="AIRPORT EXTERIOR - NON-SECURE AREA"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="AIRPORT TERMINAL LOWER LEVEL - SECURE AREA"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="AIRPORT TERMINAL LOWER LEVEL - NON-SECURE AREA"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="AIRPORT TERMINAL NON-TERMINAL - NON-SECURE AREA"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="AIRPORT TERMINAL NON-TERMINAL - SECURE AREA"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="AIRPORT TERMINAL TERMINAL - NON-SECURE AREA"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="AIRPORT TERMINAL TERMINAL - SECURE AREA"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="AIRPORT TERMINAL UPPER LEVEL - NON-SECURE AREA"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="AIRPORT TERMINAL UPPER LEVEL - SECURE AREA"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="AIRPORT TERMINAL MEZZANINE - NON-SECURE AREA"] <- "PUBLIC BUILDING/GROUNDS"
crimes$Location.Description[crimes$Location.Description=="AIRPORT VENDING ESTABLISHMENT"] <- "PUBLIC BUILDING/GROUNDS"

crimes$Location.Description[crimes$Location.Description=="RESTAURANT"] <- "RESTAURANT/BAR"
crimes$Location.Description[crimes$Location.Description=="BAR OR TAVERN"] <- "RESTAURANT/BAR"

crimes$Location.Description[crimes$Location.Description=="SMALL RETAIL STORE"] <- "STORE"
crimes$Location.Description[crimes$Location.Description=="DRUG STORE"] <- "STORE"
crimes$Location.Description[crimes$Location.Description=="GROCERY FOOD STORE"] <- "STORE"
crimes$Location.Description[crimes$Location.Description=="APPLIANCE STORE"] <- "STORE"
crimes$Location.Description[crimes$Location.Description=="CLEANING STORE"] <- "STORE"
crimes$Location.Description[crimes$Location.Description=="CONVENIENCE STORE"] <- "STORE"
crimes$Location.Description[crimes$Location.Description=="TAVERN/LIQUOR STORE"] <- "STORE"
crimes$Location.Description[crimes$Location.Description=="DEPARTMENT STORE"] <- "STORE"

crimes$Location.Description[crimes$Location.Description=="AIRCRAFT"] <- "TRANSPORT"
crimes$Location.Description[crimes$Location.Description=="CTA TRAIN"] <- "TRANSPORT"
crimes$Location.Description[crimes$Location.Description=="TAXICAB"] <- "TRANSPORT"
crimes$Location.Description[crimes$Location.Description=="HIGHWAY/EXPRESSWAY"] <- "TRANSPORT"
crimes$Location.Description[crimes$Location.Description=="HIGHWAY/EXPRESSWAY"] <- "TRANSPORT"
crimes$Location.Description[crimes$Location.Description=="VEHICLE NON-COMMERCIAL"] <- "TRANSPORT"
crimes$Location.Description[crimes$Location.Description=="VEHICLE-COMMERCIAL"] <- "TRANSPORT"
crimes$Location.Description[crimes$Location.Description=="BOAT/WATERCRAFT"] <- "TRANSPORT"
crimes$Location.Description[crimes$Location.Description=="OTHER COMMERCIAL TRANSPORTATION"] <- "TRANSPORT"
crimes$Location.Description[crimes$Location.Description=="CTA BUS STOP"] <- "TRANSPORT"
crimes$Location.Description[crimes$Location.Description=="CTA BUS"] <- "TRANSPORT"
crimes$Location.Description[crimes$Location.Description=="CTA STATION"] <- "TRANSPORT"

crimes$Location.Description[crimes$Location.Description=="ATM (AUTOMATIC TELLER MACHINE)"] <- "BANK"


vars2<-c("RESIDENCE", "RESTAURANT/BAR","STORE","PARKING LOT","GAS STATION","STREET/SIDEWALK/PARK","PUBLIC BUILDING/GROUNDS","SCHOOL/COLLEGE/UNIVERSITY","TRANSPORT","BANK", "HOTEL/MOTEL")
crimes<-filter(crimes, Location.Description %in% vars2)

theft<-data2%>%
  filter((Primary.Type== "THEFT"))%>%
  filter((Year != 2017))%>%
  group_by(Year)%>%
  summarize(Theft=n())%>%top_n(10,Theft)

MVtheft<-data2%>%
  filter((Primary.Type== "MOTOR VEHICLE THEFT"))%>%
  filter((Year != 2017))%>%
  group_by(Year)%>%
  summarize(MotorVehicleTheft=n())%>%top_n(10,MotorVehicleTheft)

burglary<-data2%>%
  filter((Primary.Type== "BURGLARY"))%>%
  filter((Year != 2017))%>%
  group_by(Year)%>%
  summarize(Burglary=n())%>%top_n(10,Burglary)

robbery<-data2%>%
  filter((Primary.Type== "ROBBERY"))%>%
  filter((Year != 2017))%>%
  group_by(Year)%>%
  summarize(Robbery=n())%>%top_n(10,Robbery)

TypeByYear1 <- inner_join(burglary,MVtheft, by = "Year")
TypeByYear2 <- inner_join(TypeByYear1,robbery, by = "Year")
TypeByYear <- inner_join(TypeByYear2,theft, by = "Year")

residence<-data2%>%
  filter((Location.Description == "RESIDENCE"))%>%
  filter((Year != 2017))%>%
  group_by(Year)%>%
  summarize(Residence=n())%>%top_n(10,Residence)

RestaurantBar<-data2%>%
  filter(str_detect(Location.Description, "RESTAURANT"))%>%
  filter((Year != 2017))%>%
  group_by(Year)%>%
  summarize(Restaurant.Bar=n())%>%top_n(10,Restaurant.Bar)

store<-data2%>%
  filter(str_detect(Location.Description, "STORE"))%>%
  filter((Year != 2017))%>%
  group_by(Year)%>%
  summarize(Store=n())%>%top_n(10,Store)

parking<-data2%>%
  filter(str_detect(Location.Description, "PARKING LOT"))%>%
  filter((Year != 2017))%>%
  group_by(Year)%>%
  summarize(ParkingLot=n())%>%top_n(10,ParkingLot)

gas<-data2%>%
  filter((Location.Description== "GAS STATION"))%>%
  filter((Year != 2017))%>%
  group_by(Year)%>%
  summarize(GasStation=n())%>%top_n(10,GasStation)

street<-data2%>%
  filter(str_detect(Location.Description, "STREET"))%>%
  filter((Year != 2017))%>%
  group_by(Year)%>%
  summarize(StreetSidewalkPark=n())%>%top_n(10,StreetSidewalkPark)

building<-data2%>%
  filter(str_detect(Location.Description, "PUBLIC"))%>%
  filter((Year != 2017))%>%
  group_by(Year)%>%
  summarize(PublicBuildingGrounds=n())%>%top_n(10,PublicBuildingGrounds)

school<-data2%>%
  filter(str_detect(Location.Description, "SCHOOL"))%>%
  filter((Year != 2017))%>%
  group_by(Year)%>%
  summarize(SchoolCollegeUniversity=n())%>%top_n(10,SchoolCollegeUniversity)

transport<-data2%>%
  filter(str_detect(Location.Description, "TRANSPORT"))%>%
  filter((Year != 2017))%>%
  group_by(Year)%>%
  summarize(Transport=n())%>%top_n(10,Transport)

bank<-data2%>%
  filter((Location.Description== "BANK"))%>%
  filter((Year != 2017))%>%
  group_by(Year)%>%
  summarize(Bank=n())%>%top_n(10,Bank)

hotel<-data2%>%
  filter(str_detect(Location.Description, "HOTEL"))%>%
  filter((Year != 2017))%>%
  group_by(Year)%>%
  summarize(HotelMotel=n())%>%top_n(10,HotelMotel)

LocationByYear1 <- inner_join(residence,RestaurantBar, by = "Year")
LocationByYear2 <- inner_join(LocationByYear1,store, by = "Year")
LocationByYear3 <- inner_join(LocationByYear2,parking, by = "Year")
LocationByYear4 <- inner_join(LocationByYear3,gas, by = "Year")
LocationByYear5 <- inner_join(LocationByYear4,street, by = "Year")
LocationByYear6 <- inner_join(LocationByYear5,building, by = "Year")
LocationByYear7 <- inner_join(LocationByYear6,school, by = "Year")
LocationByYear8 <- inner_join(LocationByYear7,transport, by = "Year")
LocationByYear9 <- inner_join(LocationByYear8,bank, by = "Year")
LocationByYear <- inner_join(LocationByYear9,hotel, by = "Year")