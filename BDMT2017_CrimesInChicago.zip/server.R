library(leaflet)
library(RColorBrewer)
library(scales)
library(lattice)
library(dplyr)
library(ggplot2)
library(ggthemes)

#Limiting the number of data for showing on map (for too much data, we got error)
mapdata<-crimes[sample(nrow(crimes), 5000), ]
data<-crimes

function(input, output, session) {
  color <- colorFactor(cm.colors(6), data$Year)
  color2 <- colorRampPalette(rev(brewer.pal(20, "Spectral")))
#cm.colors(6) rainbow(6) RColorBrewer::brewer.pal(n = 6, name = 'Set2')
  
  output$map <- renderLeaflet({
    leaflet() %>%
      addTiles(
        urlTemplate = "//{s}.tiles.mapbox.com/v3/jcheng.map-5ebohr46/{z}/{x}/{y}.png",
        attribution = 'Maps by <a href="http://www.mapbox.com/">Mapbox</a>'
      ) %>%
      setView(lng = -87.48, lat = 41.86, zoom = 10)
  })
  observe({
    colorBy <- input$year
    #sizeBy <- input$year
    mapdata%>%filter(between(Year, input$year[1], input$year[2]) & Primary.Type==input$type)
    leafletProxy("map", data = mapdata) %>%
      clearShapes() %>%
      addCircles(~Longitude, ~Latitude, weight = 3, radius=20, color=~color(Year), stroke = TRUE, fillOpacity = 0.8) 
    })
  
  output$CL <- renderPlot({
    colorBy<-input$year
    df<-data%>%
      filter(between(Year, input$year[1], input$year[2]) & 
                          Primary.Type==input$type)%>%
      group_by(Year,Location.Description)%>%
      summarize(NumberOfCrimes=n())%>%top_n(10,NumberOfCrimes)%>%
      arrange(desc(NumberOfCrimes))
    
    ggplot(df,aes(x=Location.Description,y=NumberOfCrimes, fill=Year))+
      geom_bar(stat="identity")+
      scale_fill_gradientn(colours=cm.colors(6))+
      labs(title="Crimes by Location Description",x = "Location", y="Number of Crimes")+
      theme_minimal()+theme(plot.title = element_text(size = rel(1.5)),axis.text.x = element_text(angle = 90, hjust = 1))
    
    
  })
  
  output$graf <- renderPlot({
    df<-data2%>%
      filter((Year != 2017))%>%
      group_by(Year,Primary.Type)%>%
      summarize(NumberOfCrimes=n())%>%top_n(10,NumberOfCrimes)%>%
      arrange(desc(NumberOfCrimes))
    
    g <- ggplot(df,aes(x=Year,y=NumberOfCrimes, fill=Year))+
      geom_bar(stat="identity")+
      #scale_fill_gradientn(colours = color(1))+
      labs(title="Crimes by year",x = "Type of crime", y="Number of Crimes")+
      theme_minimal()+theme(plot.title = element_text(size = rel(1.5)),axis.text.x = element_text(angle = 90, hjust = 1))
    
    g+facet_grid(.~Primary.Type)+ggtitle("Type of crime by year") 
    
  })
  
  output$table1 <- renderDataTable({
    TypeByYear
    })
  
  output$table2 <- renderDataTable({
    LocationByYear
    })
}
