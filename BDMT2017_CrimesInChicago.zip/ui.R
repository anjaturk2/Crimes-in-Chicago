library(leaflet)
library(shiny)
library(ggmap)

# Choices for drop-down - allready defined in global.R
#varyr<-c("2012","2013","2013","2014","2015","2016","2017")
#        "CRIMINAL DAMAGE","KIDNAPPING","ARSON")

navbarPage("Chicago Crimes", id="nav",

  tabPanel("Interactive map",
    div(class="outer",

      tags$head(
        # Include custom CSS
        includeCSS("styles.css"),
        includeScript("gomap.js")
      ),

      leafletOutput("map", width="100%", height="100%"),

      absolutePanel(id = "controls", class = "panel-default", fixed = TRUE,
        draggable = FALSE, top = 60, left = "auto", right = 5, bottom = "auto",
        width = 400, height = "auto",

        h2("Chicago Crimes On Map"),

        selectInput("type", "Type of crime", vars),
        
        sliderInput("year",
                    "Year:",
                    min = 2012,
                    max = 2017,
                    value = c(2012,2017),
                    sep=""
        ),

      plotOutput("CL", height = 400)
      ),

      tags$div(id="cite",
        'Kaggle Data: ', tags$em('An extensive dataset of crimes in Chicago (2001-2017), by City of Chicago')
      )
    )
  ),
  tabPanel("Graph of crimes by year",
           div(class="outer",
               plotOutput("graf", height = 600, width = 1350)
               )
  ),
  
  tabPanel("Table: type of crime by year",
           div(class="outer",
               dataTableOutput('table1')
           )
  ),
  tabPanel("Table: location of crime by year",
           div(class="outer",
               dataTableOutput('table2')
           )
  ),
  conditionalPanel("false", icon("crosshair"))
)


